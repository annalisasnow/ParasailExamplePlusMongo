#include <iostream>
#include <mongocxx/client.hpp>
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
